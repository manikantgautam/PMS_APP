package com.profitcount.profitcount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfitcountApplicationTests {

	@Test
	void contextLoads() {
	}

}
