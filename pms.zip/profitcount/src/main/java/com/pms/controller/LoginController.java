package com.pms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.pms.constatnts.HttpMessage;
import com.pms.dto.Organization;
import com.pms.dto.RegistartionRequest;
import com.pms.dto.ResultObject;
import com.pms.dto.User;
import com.pms.service.LoginService;

@RestController
public class LoginController {
	
	@Autowired 
	LoginService loginService;
	
    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	 @PostMapping("/login")
	  public ResultObject validateLogin(@RequestBody User usr) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In Get loged In detals for user ",usr.getUserName());
		 resulObject = loginService.validateLogin(usr);
		
		 logger.debug("Out Get loged In detals for user ",usr.getUserName());
		 return resulObject;
	  }
	 @GetMapping("/chk")
	 public void chk() {
		 String uri = "/?param1=ab&param2=cd&param2=ef";
		    MultiValueMap<String, String> parameters =
		            UriComponentsBuilder.fromUriString(uri).build().getQueryParams();
		    List<String> param1 = parameters.get("param1");
		    List<String> param2 = parameters.get("param2");
		    System.out.println("param1: " + param1.get(0));
		    System.out.println("param2: " + param2.get(0) + "," + param2.get(1));
	 }
	 @PostMapping("/register")
	  public ResultObject registerUser(@RequestBody User usr) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In registerUser user ",usr.getUserName());
		 resulObject = loginService.RegisterUser(usr);
		 logger.debug("Out registerUser user ",usr.getUserName());
		 return resulObject;
	  }
	
	 
	 @PostMapping("/registerReq")
	  public ResultObject registerUserReq(@RequestBody RegistartionRequest regReq) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In registerUserReq user ",regReq.getEmail());
		 resulObject = loginService.createRegReq(regReq);
		 logger.debug("Out registerUser user ",regReq.getEmail());
		 return resulObject;
	  }
	 
	 @PostMapping("/isvalidtoken")
	  public ResultObject isValidtoken(@RequestParam String token) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In isValidtoken user ",token);
		 RegistartionRequest req = new RegistartionRequest();
		 req.setToken(token);
		 resulObject = loginService.isValidRegistrationRequest(req);
		 logger.debug("Out isValidtoken user ",token);
		 return resulObject;
	  }

}
