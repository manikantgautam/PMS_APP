package com.pms.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.constatnts.HttpMessage;
import com.pms.dto.Organization;
import com.pms.dto.ResultObject;
import com.pms.dto.User;
import com.pms.service.OrganizationService;

@RestController
public class OrganizationController {

    private static final Logger logger = LoggerFactory.getLogger(OrganizationController.class);

	
    @Autowired 
    OrganizationService orgService;
    
	 @PostMapping("/organization/create")
	  public ResultObject createOrganization(@RequestBody Organization org) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In createOrganization",org.getOrganizationName());
		 resulObject = orgService.createOrganization(org);
		 logger.debug("Out createOrganization ",org.getOrganizationName());
		 return resulObject;
	  }
	 @GetMapping("/organization")
	  public ResultObject getOrganization(@RequestParam int orgId) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In getOrganization",orgId);
		 resulObject = orgService.getOrganizationByOrgId(orgId);
		 logger.debug("Out getOrganization ",orgId);
		 return resulObject;
	  }
	 @GetMapping("/organization/all")
	  public ResultObject getAllOrganizationOfUser(@RequestParam int userId) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In getAllOrganizationOfUser",userId);
		 resulObject = orgService.getAllOrganizationOfUser(userId);
		 logger.debug("Out getAllOrganizationOfUser ",userId);
		 return resulObject;
	  }
	 @PostMapping("/createOrg")
	  public ResultObject createOrg(@RequestBody Organization org) {
		 ResultObject resulObject = new ResultObject(200, HttpMessage.ERROR.name(), null);
		 logger.debug("In createOrg org ",org.getOrganizationName());
		 resulObject = orgService.createOrganization(org);
		 logger.debug("Out createOrg org ",org.getOrganizationName());
		 return resulObject;
	  }
}
