/**
 * 
 */
package com.pms.constatnts;

/**
 * @author mangautam
 *
 */
public enum Status {
	
	ACTIVE(1,"active"),SOFT_DELETE(2,"soft_delete"),DELETE(3,"delete"),INACTIVE(4,"inactive");

	private int statusId;
	
	private String statusString;
	
	Status(int statusId,String statusString){
		this.statusId=statusId;
		this.statusString=statusString;
	}
	/**
	 * 
	 * @param statusId
	 * @return
	 */
	public static Status getStatusById(int statusId) {
	    for(Status e : values()) {
	        if(e.statusId==(statusId)) 
	        return e;
	    }
	    return null;
	}
	/**
	 * 
	 * @param statusStr
	 * @return
	 */
	public static Status getStatusByStatus(String statusStr) {
	    for(Status e : values()) {
	        if(e.statusString.equals(statusStr)) 
	        return e;
	    }
	    return null;
	}
	
	public static int getNumVal(Status status) {
		 for(Status e : values()) {
		        if(e.statusString.equals(status)) 
		        return e.statusId;
		    }
		 return 0;
	}
}
