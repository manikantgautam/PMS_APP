package com.pms.constatnts;
public enum HttpMessage 
    { 
        SUCCESS, ERROR; 
    } 