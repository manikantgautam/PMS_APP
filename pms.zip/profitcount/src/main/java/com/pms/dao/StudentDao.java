package com.pms.dao;

import java.util.List;

import com.pms.entity.Student;

public interface StudentDao {
   
	List<Student> getAllStudents();

    Student getStudentById(int id);

    void removeStudentById(int id);

    void updateStudent(Student student);

    void insertStudentToDb(Student student);
}
