package com.pms.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.pms.constatnts.Status;
import com.pms.dao.OrganizationDao;
import com.pms.dto.Organization;

@Repository
public class OrganizationDaoImpl implements OrganizationDao{
	
    private static final Logger logger = LoggerFactory.getLogger(OrganizationDao.class);
    
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Override
	public Organization getOrganizationByOrgId(int orgId) {
		logger.debug("In getOrganizationByOrgId by orgId ",orgId);
		String getUser = "select * from  organization where org_id = ? ";
		List<Organization> queryForObject = null;
		Organization organization=null;
		try {
			queryForObject =  jdbcTemplate.query(getUser,new Object[]{orgId},new RowMapper<Organization>() {
				@Override
				public Organization mapRow(ResultSet rs, int rowNum) throws SQLException {
					Organization org = new Organization();
					org.setOrganizationName(rs.getString("org_name"));
					org.setUserId(rs.getInt("userid"));
					org.setOrganizationId(rs.getInt("org_id"));
			        return org;
				}
			});
			if(queryForObject ==null ) {
				organization = new Organization();;
			}else {
				organization =queryForObject.get(0);
			}
		} catch (Exception e) {
			organization = new Organization();;
		}
		logger.debug("Out getOrganizationByOrgId for userId ",orgId);
		return organization;
	}

	@Override
	public List<Organization> getAllUsersOrganization(int userId) {
		logger.debug("In getAllUsersOrganization by userId ",userId);
		String getUser = "select * from  organization where userid = ? ";
		List<Organization> queryForObject = null;
		try {
			queryForObject =  jdbcTemplate.query(getUser,new Object[]{userId},new RowMapper<Organization>() {
				@Override
				public Organization mapRow(ResultSet rs, int rowNum) throws SQLException {
					Organization org = new Organization();
					org.setOrganizationName(rs.getString("org_name"));
					org.setUserId(rs.getInt("userid"));
					org.setOrganizationId(rs.getInt("org_id"));
			        return org;
				}
			});
			if(queryForObject ==null ) {
				queryForObject = new ArrayList<Organization>();;
			}
		} catch (Exception e) {
			queryForObject = new ArrayList<Organization>();;
		}
		logger.debug("Out getOrganizationByOrgId for userId ",userId);
		return queryForObject;
	}

	@Override
	public int createOrganization(Organization org) {
		int update = 0;
		try {
			SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate);
			simpleJdbcInsert
			    .withTableName("organization")
			    .usingGeneratedKeyColumns("org_id");
			    SqlParameterSource params = new MapSqlParameterSource()
			    .addValue("userid", org.getUserId())
			    .addValue("org_name",org.getOrganizationName())
			    .addValue("createdOn",new Date())
			    .addValue("modifiedOn",new Date())
			    .addValue("pincode",org.getPincode())
			    .addValue("contact",org.getContact())
			    .addValue("country",org.getCountry())
			    .addValue("state",org.getState())
			    .addValue("city",org.getCity())
			    .addValue("commencement_date", org.getCommensementDate())
			    .addValue("org_owner_name", org.getOrganizationOwnerName())
			    .addValue("status",1);
			Number number = simpleJdbcInsert.executeAndReturnKey(params);
			update = number.intValue();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return update ;
	}

}
