package com.pms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pms.dto.RegistartionRequest;
import com.pms.dto.Role;
import com.pms.dto.User;


@Repository
public interface RegistrationLoginDao {
	
	User getUserDetail(User usr);

	int createUser(User user);

	User getUserByUserName(String userName);
	
	List<Role> getROleByUserId(int userId);
	
	int createRegistrationRequest(RegistartionRequest regReq);

	RegistartionRequest getTokenRequestByToken(RegistartionRequest regReq);

	boolean inactivateRegistrationToken(RegistartionRequest req);
}
