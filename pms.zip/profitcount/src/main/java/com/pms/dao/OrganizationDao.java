package com.pms.dao;

import java.util.List;

import com.pms.dto.Organization;

public interface OrganizationDao {
	
	Organization getOrganizationByOrgId(int orgId);
	
	List<Organization> getAllUsersOrganization(int userId);
	
	int createOrganization(Organization org);
}
