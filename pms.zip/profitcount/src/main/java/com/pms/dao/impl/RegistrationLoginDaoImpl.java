package com.pms.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.pms.constatnts.Status;
import com.pms.dao.RegistrationLoginDao;
import com.pms.dto.RegistartionRequest;
import com.pms.dto.Role;
import com.pms.dto.User;

import jdk.internal.net.http.common.Log;

@Repository
public class RegistrationLoginDaoImpl implements RegistrationLoginDao {
    private static final Logger logger = LoggerFactory.getLogger(RegistrationLoginDaoImpl.class);


	@Autowired
    private JdbcTemplate jdbcTemplate;
	
		
	@Override
	public User getUserDetail(User usr) {
		logger.debug("In getUserDetail for user ",usr.getUserName());
		String getUser = "select * from  user where username = ? AND password = ? ";
		List<User> queryForObject = null;
		User user=null;
		try {
		//	queryForObject= jdbcTemplate.queryForObject(getUser, new Object[]{usr.getUserName(),usr.getPassword()}, new UserRowMapper());
			queryForObject =  jdbcTemplate.query(getUser,new Object[]{usr.getUserName(),usr.getPassword()},new RowMapper<User>() {
				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
			    	user.setUserId(rs.getInt("userid"));
			    	user.setUserName(rs.getString("username"));
			    	user.setUserStatus(Status.getStatusById(rs.getInt("status")));
			        return user;
				}
			});
			if(!queryForObject.isEmpty()) {
				user = queryForObject.get(0);
			}
		} catch (Exception e) {
			user = null;
		}
		logger.debug("Out getUserDetail for user ",usr.getUserName());
		return user;
	}



	@Override
	public int createUser(User user) {
		int update = 0;
		try {
			//String sql = "INSERT INTO USER  VALUES (default,?,?, ?, ?, ?,?,?,?)";
			//update = jdbcTemplate.update(sql,user.getFirstName(),user.getLastName(), user.getUserName(),user.getEmail(),user.getPassword(),new Date(),null,1);
			SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate);
			simpleJdbcInsert
			    .withTableName("USER")
			    .usingGeneratedKeyColumns("userid");
			SqlParameterSource params = new MapSqlParameterSource()
			    .addValue("username", user.getUserName())
			    .addValue("email",user.getEmail())
			    .addValue("password",user.getPassword())
			    .addValue("createdOn",new Date())
			    .addValue("modifiedOn",null)
			    .addValue("status",1)
			    .addValue("firstName",user.getFirstName())
			    .addValue("lastName",user.getLastName());
			Number number = simpleJdbcInsert.executeAndReturnKey(params);
			update = number.intValue();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return update;
	}



	@Override
	public User getUserByUserName(String userName) {
		String getUser = "select * from  user where username = ?  ";
		List<User> queryForObject = null;
		User user=null;
		try {
		//	queryForObject= jdbcTemplate.queryForObject(getUser, new Object[]{usr.getUserName(),usr.getPassword()}, new UserRowMapper());
			queryForObject =  jdbcTemplate.query(getUser,new Object[]{userName},new RowMapper<User>() {
				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
			    	user.setUserId(rs.getInt("userid"));
			    	user.setUserName(rs.getString("username"));
			    	user.setPassword(rs.getString("password"));
			    	user.setUserStatus(Status.getStatusById(rs.getInt("status")));
			        return user;
				}
			});
			if(!queryForObject.isEmpty()) {
				user = queryForObject.get(0);
			}
		} catch (Exception e) {
			user = null;
		}
		logger.debug("Out userName for user ",userName);
		return user;
	}



	@Override
	public List<Role> getROleByUserId(int userId) {
		String getUser = "select * from Role where userId= ?  ";
		List<Role> queryForObject = null;
		try {
			queryForObject =  jdbcTemplate.query(getUser,new Object[]{userId},new RowMapper<Role>() {
				@Override
				public Role mapRow(ResultSet rs, int rowNum) throws SQLException {
					Role role = new Role();
					role.setRoleName(rs.getString("roleName"));
			    	return role;
				}
			});
			if(queryForObject.isEmpty()) {
				queryForObject =new ArrayList<Role>();
			}
		} catch (Exception e) {
			queryForObject =new ArrayList<Role>();
		}
		logger.debug("Out userName for user ",userId);
		return queryForObject;
	}



	@Override
	public int createRegistrationRequest(RegistartionRequest regReq) {
		int update = 0;
		try {
			SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate);
			simpleJdbcInsert
			    .withTableName("registration_request")
			    .usingGeneratedKeyColumns("userid");
			SqlParameterSource params = new MapSqlParameterSource()
			    .addValue("firstname", regReq.getFirstname())
			    .addValue("lastname",regReq.getLastname())
			    .addValue("email",regReq.getEmail())
			    .addValue("createdOn",new Date())
			    .addValue("modifiedOn",null)
			    .addValue("token",regReq.getToken())
			    .addValue("invitationstatus",1)
			    .addValue("invitecount",0);
			Number number = simpleJdbcInsert.executeAndReturnKey(params);
			update = number.intValue();
		} catch (Exception e) {
			update = 0;
		}
		return update;
	}



	@Override
	public RegistartionRequest getTokenRequestByToken(RegistartionRequest regReq) {
		String getUser = "select * from registration_request where token= ?  ";
		List<RegistartionRequest> queryForObject = null;
		RegistartionRequest isValidToken = null;
		try {
			queryForObject =  jdbcTemplate.query(getUser,new Object[]{regReq.getToken()},new RowMapper<RegistartionRequest>() {
				@Override
				public RegistartionRequest mapRow(ResultSet rs, int rowNum) throws SQLException {
					RegistartionRequest regReq = new RegistartionRequest();
					regReq.setReqStatus(rs.getInt("invitationstatus"));
					regReq.setFirstname(rs.getString("firstname"));
					regReq.setLastname(rs.getString("lastname"));
					regReq.setEmail(rs.getString("email"));
			    	return regReq;
				}
			});
			if(CollectionUtils.isEmpty(queryForObject)) {
				queryForObject =new ArrayList<RegistartionRequest>();
			}else {
				isValidToken = queryForObject.get(0);
			}
		} catch (Exception e) {
			queryForObject =new ArrayList<RegistartionRequest>();
		}
		logger.debug("Out isValidRegistrationReq for token ",regReq.getToken());
		return isValidToken;
	}



	@Override
	public boolean inactivateRegistrationToken(RegistartionRequest req) {
		logger.debug("IN inactivateRegistrationToken ",req.getToken());
		
		int update = this.jdbcTemplate.update(
                "update registration_request set invitationstatus = ? where token = ?", 
                Status.getNumVal(Status.INACTIVE), req.getToken());
		logger.debug("Out inactivateRegistrationToken ",req.getToken());
		return update>0?true:false;
	}
	
	
	
	

}

class UserRowMapper implements RowMapper<User> {

    @Override
    public User mapRow(ResultSet rs, int rowNum) throws SQLException {

    	User user = new User();
    	user.setUserId(rs.getInt("userid"));
    	user.setUserName(rs.getString("username"));
    	user.setUserStatus(Status.getStatusById(rs.getInt("status")));
        //user.setCreatedDate(rs.getTimestamp("created_date").toLocalDateTime());
        return user;

    }
}
