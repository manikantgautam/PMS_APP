package com.pms.dto;

import com.pms.constatnts.HttpMessage;

public class ResultObject {
	private int status;
	
	private String message;
	
	private Object data;
	
	public ResultObject() {
		super();
		this.status = 200;
		this.message = HttpMessage.SUCCESS.name();
		this.data = null;
	}


	public ResultObject(int status, String message, Object data) {
		super();
		this.status = status;
		this.message = message;
		this.data = data;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
	
}
