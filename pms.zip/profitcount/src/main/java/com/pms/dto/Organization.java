package com.pms.dto;

import java.util.Date;

/**
 * 
 * @author mangautam
 *
 */
public class Organization {
	
	int organizationId;
	
	int userId;
	
	String organizationName;
	
	String organizationOwnerName;
	
	String contact;
	
	String email;
	
	String address;
	
	String country;
	
	String state;
	
	String city;
	
	String pincode;
	
	Date commensementDate;
		
	Date createdOn;
	
	Date modifiedOn;
	
	int status;

	public int getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(int organizationId) {
		this.organizationId = organizationId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getOrganizationOwnerName() {
		return organizationOwnerName;
	}

	public void setOrganizationOwnerName(String organizationOwnerName) {
		this.organizationOwnerName = organizationOwnerName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Date getCommensementDate() {
		return commensementDate;
	}

	public void setCommensementDate(Date commensementDate) {
		this.commensementDate = commensementDate;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((commensementDate == null) ? 0 : commensementDate.hashCode());
		result = prime * result + ((contact == null) ? 0 : contact.hashCode());
		result = prime * result + organizationId;
		result = prime * result + ((organizationName == null) ? 0 : organizationName.hashCode());
		result = prime * result + ((organizationOwnerName == null) ? 0 : organizationOwnerName.hashCode());
		result = prime * result + ((pincode == null) ? 0 : pincode.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + status;
		result = prime * result + userId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Organization other = (Organization) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (commensementDate == null) {
			if (other.commensementDate != null)
				return false;
		} else if (!commensementDate.equals(other.commensementDate))
			return false;
		if (contact == null) {
			if (other.contact != null)
				return false;
		} else if (!contact.equals(other.contact))
			return false;
		if (organizationId != other.organizationId)
			return false;
		if (organizationName == null) {
			if (other.organizationName != null)
				return false;
		} else if (!organizationName.equals(other.organizationName))
			return false;
		if (organizationOwnerName == null) {
			if (other.organizationOwnerName != null)
				return false;
		} else if (!organizationOwnerName.equals(other.organizationOwnerName))
			return false;
		if (pincode == null) {
			if (other.pincode != null)
				return false;
		} else if (!pincode.equals(other.pincode))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (status != other.status)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Organization [organizationId=" + organizationId + ", userId=" + userId + ", organizationName="
				+ organizationName + ", organizationOwnerName=" + organizationOwnerName + ", contact=" + contact
				+ ", email=" + email + ", address=" + address + ", country=" + country + ", state=" + state + ", city="
				+ city + ", pincode=" + pincode + ", commensementDate=" + commensementDate + ", createdOn=" + createdOn
				+ ", modifiedOn=" + modifiedOn + ", status=" + status + "]";
	}
	
	

	}
