package com.pms.dto;

import java.util.Date;

public class RegistartionRequest {
	public RegistartionRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	private int registrationRequestId;
	
	private String firstname;
	
	private String lastname;
	
	private String email;
	
	private Date createdOn;
	
	private Date modifiedOn;
	
	private int reqStatus;

	private String token ;
	
	public int getRegistrationRequestId() {
		return registrationRequestId;
	}

	public void setRegistrationRequestId(int registrationRequestId) {
		this.registrationRequestId = registrationRequestId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public int getReqStatus() {
		return reqStatus;
	}

	public void setReqStatus(int reqStatus) {
		this.reqStatus = reqStatus;
	}

	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdOn == null) ? 0 : createdOn.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstname == null) ? 0 : firstname.hashCode());
		result = prime * result + ((lastname == null) ? 0 : lastname.hashCode());
		result = prime * result + ((modifiedOn == null) ? 0 : modifiedOn.hashCode());
		result = prime * result + registrationRequestId;
		result = prime * result + reqStatus;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegistartionRequest other = (RegistartionRequest) obj;
		if (createdOn == null) {
			if (other.createdOn != null)
				return false;
		} else if (!createdOn.equals(other.createdOn))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstname == null) {
			if (other.firstname != null)
				return false;
		} else if (!firstname.equals(other.firstname))
			return false;
		if (lastname == null) {
			if (other.lastname != null)
				return false;
		} else if (!lastname.equals(other.lastname))
			return false;
		if (modifiedOn == null) {
			if (other.modifiedOn != null)
				return false;
		} else if (!modifiedOn.equals(other.modifiedOn))
			return false;
		if (registrationRequestId != other.registrationRequestId)
			return false;
		if (reqStatus != other.reqStatus)
			return false;
		if(token != other.token)
			return false;
		return true;
	}

	public RegistartionRequest(int registrationRequestId, String firstname, String lastname, String email,
			Date createdOn, Date modifiedOn, int reqStatus) {
		super();
		this.registrationRequestId = registrationRequestId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.createdOn = createdOn;
		this.modifiedOn = modifiedOn;
		this.reqStatus = reqStatus;
	}
	
	
}
