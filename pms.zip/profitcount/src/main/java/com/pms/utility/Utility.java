package com.pms.utility;

import java.util.UUID;

public class Utility {
	public static String generateUUIDString(){
		return  UUID.randomUUID().toString();
	}
}
