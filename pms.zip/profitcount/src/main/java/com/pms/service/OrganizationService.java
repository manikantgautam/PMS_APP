package com.pms.service;

import com.pms.dto.Organization;
import com.pms.dto.ResultObject;

public interface OrganizationService {
	
	ResultObject createOrganization( Organization org);

	ResultObject getOrganizationByOrgId ( int orgId);
	
	ResultObject getAllOrganizationOfUser(int userId);
}
