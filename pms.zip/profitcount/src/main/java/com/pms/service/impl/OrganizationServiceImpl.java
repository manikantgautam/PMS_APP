package com.pms.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.constatnts.HttpMessage;
import com.pms.dao.OrganizationDao;
import com.pms.dto.Organization;
import com.pms.dto.ResultObject;
import com.pms.service.OrganizationService;

@Service
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	OrganizationDao  orgDao;
	
    private static final Logger logger = LoggerFactory.getLogger(OrganizationService.class);

	
	@Override
	public ResultObject createOrganization(Organization org) {
		logger.debug("In createOrganization org ",org);
		ResultObject rs=null;
		int operationStatus = orgDao.createOrganization(org);
		if(operationStatus>0) {
			org.setOrganizationId(operationStatus);
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),org);
		}
		logger.debug("Out createOrganization for org ",org.getOrganizationName());
		return rs;
	}

	@Override
	public ResultObject getOrganizationByOrgId(int orgId) {
		logger.debug("In getOrganizationByOrgId org ",orgId);
		ResultObject rs=null;
		Organization operationStatus = orgDao.getOrganizationByOrgId(orgId);
		if(operationStatus!=null) {
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),operationStatus);
		}
		logger.debug("Out getOrganizationByOrgId for org ",orgId);
		return rs;
	}

	@Override
	public ResultObject getAllOrganizationOfUser(int userId) {
		logger.debug("In getAllOrganizationOfUser for user ",userId);
		ResultObject rs=null;
		List<Organization> operationList = orgDao.getAllUsersOrganization(userId);
		if(operationList!=null && !operationList.isEmpty()) {
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),operationList);
		}
		logger.debug("Out getOrganizationByOrgId for org ",userId);
		return rs;
	}

}
