package com.pms.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.pms.constatnts.HttpMessage;
import com.pms.dao.RegistrationLoginDao;
import com.pms.dto.RegistartionRequest;
import com.pms.dto.ResultObject;
import com.pms.dto.Role;
import com.pms.dto.User;
import com.pms.service.LoginService;
import com.pms.utility.Utility;
@Service
public class LoginServiceImpl implements LoginService{

    private static final Logger logger = LoggerFactory.getLogger(LoginService.class);
    private static final String CHARSET_UTF8 = "UTF-8";
	@Autowired
	RegistrationLoginDao loginDao;
	
	@Autowired
    private JavaMailSender javaMailSender;
	
	@Autowired  
	private VelocityEngine velocityEngine;
	
	@Override
	public ResultObject validateLogin(User user) {
		logger.debug("In validateLogin for user ",user.getUserName());
		ResultObject rs = null;
		User usr = loginDao.getUserDetail(user);
		if(usr!=null) {
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),usr);
		}
		logger.debug("Out validateLogin for user ",user.getUserName());
		return rs;
	}

	@Override
	public ResultObject RegisterUser(User user) {
		logger.debug("In RegisterUser for user ",user);
		ResultObject rs=null;
		int operationStatus = loginDao.createUser(user);
		if(operationStatus>0) {
			user.setUserId(operationStatus);
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),user);
		}else {
			rs = new ResultObject(200,HttpMessage.ERROR.name(),null);
		}
		logger.debug("Out validateLogin for user ",user.getUserName());
		return rs;
	}

	@Override
	public User getUserByUserName(String userName) {
		logger.debug("In getUserBuUserName for user ",userName);
		User user=null;
		user = loginDao.getUserByUserName(userName);
		if(null!=user && user.getUserId()>0) {
			List<Role> roles = loginDao.getROleByUserId(user.getUserId());
			if(!roles.isEmpty())
			user.setRoles(roles);
		}
		logger.debug("Out getUserBuUserName for user ",user.getUserName());
		return user;
	}

	@Override
	public ResultObject createRegReq(RegistartionRequest regReq) {
		logger.debug("In createRegReq for user ",regReq.getFirstname());
		ResultObject rs=null;
		String token = Utility.generateUUIDString();
		regReq.setToken(token);
		int operationStatus = loginDao.createRegistrationRequest(regReq);
		if(operationStatus>0) {
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),regReq);
			sendEmail(regReq);
		}
		logger.debug("Out createRegReq for user ",regReq.getFirstname());
		return rs;
	}


	void sendEmail(RegistartionRequest  regReq) {
        MimeMessagePreparator preparator = new MimeMessagePreparator() {  
        	        @Override  
        	        public void prepare(MimeMessage mimeMessage) throws Exception {  
        	          MimeMessageHelper message = new MimeMessageHelper(mimeMessage);  
        	          message.setTo(regReq.getEmail());  
        	          message.setSubject("Welcome , PMS invites you to register");  
        	          Map<String, Object> model = new HashMap<String,Object>();  
        	          model.put("firstname", regReq.getFirstname());
        	          model.put("lastname",regReq.getLastname());
        	          model.put("url", "www.pms.com/?token="+regReq.getToken());
        	          model.put("currentDateTime", new Date());
        	          message.setText(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine  
        	              , "/templates/velocity/registration-confirmation.vm", CHARSET_UTF8, model), true);  
        	        }
        	      };  
        	      this.javaMailSender.send(preparator);  

    }

	@Override
	public ResultObject isValidRegistrationRequest(RegistartionRequest regReq) {
		logger.debug("IN isValidRegistrationRequest ",regReq.getToken());
		RegistartionRequest existingReq= loginDao.getTokenRequestByToken(regReq);
		ResultObject rs = null;
		if(existingReq!=null && existingReq.getReqStatus()== 1) {
		   rs = new ResultObject(200,HttpMessage.SUCCESS.name(),existingReq);
		   inactiveRegistrationRequest(regReq);
		}else {
			rs = new ResultObject(200,HttpMessage.SUCCESS.name(),null);
		}
		logger.debug("OUT isValidRegistrationRequest ",regReq.getToken());
		return rs;
	}

	@Override
	public ResultObject inactiveRegistrationRequest(RegistartionRequest req) {
		logger.debug("IN inactiveRegistrationRequest ",req.getToken());
		boolean status= loginDao.inactivateRegistrationToken(req);
		ResultObject rs = new ResultObject(200,HttpMessage.SUCCESS.name(),status);
		logger.debug("OUT inactiveRegistrationRequest ",req.getToken());
		return rs;
	}
}
