package com.pms.service;

import com.pms.dto.RegistartionRequest;
import com.pms.dto.ResultObject;
import com.pms.dto.User;


public interface LoginService {
	
	ResultObject validateLogin (User user);
	
	ResultObject RegisterUser(User user);

	User getUserByUserName(String userName);

	ResultObject createRegReq(RegistartionRequest regReq);
	
	ResultObject isValidRegistrationRequest(RegistartionRequest regReq);
	
	ResultObject inactiveRegistrationRequest(RegistartionRequest req);
}
