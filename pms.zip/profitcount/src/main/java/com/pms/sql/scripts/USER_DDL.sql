create database payroll;
use payroll;
create table user (userid int NOT NULL AUTO_INCREMENT PRIMARY KEY , username varchar(50) , email varchar(100),password varchar(100),
createdOn datetime , modifiedOn datetime,status int);

insert into user values (101,'manikant','manikant@email.com','user12345',now(),null,1);

insert into user values (102,'vikashp','vikashp@email.com','user12345',now(),null,1);


create table organization (org_id int NOT NULL AUTO_INCREMENT PRIMARY KEY , userid int  , org_name varchar(200)  , 
createdOn datetime , modifiedOn datetime,status int,
FOREIGN KEY (userid) REFERENCES user(userid) );

create table registration_request(regreqid int NOT NULL AUTO_INCREMENT PRIMARY KEY, autifirstname varchar(50),lastname varchar(50), email varchar(50),createdBy int , createdOn datetime
,modifiedOn datetime , invitationstatus int, invitecount int);